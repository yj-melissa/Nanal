-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.group_diary 구조 내보내기
CREATE TABLE IF NOT EXISTS `group_diary` (
  `group_diary_idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `diary_idx` int(10) unsigned DEFAULT NULL,
  `group_idx` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`group_diary_idx`),
  KEY `FKg6oenc89w4ew5euxktiri2q42` (`diary_idx`),
  KEY `FK18l9pmbuicqqkc3ywv3q8jwxd` (`group_idx`),
  CONSTRAINT `FK18l9pmbuicqqkc3ywv3q8jwxd` FOREIGN KEY (`group_idx`) REFERENCES `group_detail` (`group_idx`),
  CONSTRAINT `FKg6oenc89w4ew5euxktiri2q42` FOREIGN KEY (`diary_idx`) REFERENCES `diary` (`diary_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.group_diary:~37 rows (대략적) 내보내기
INSERT INTO `group_diary` (`group_diary_idx`, `diary_idx`, `group_idx`) VALUES
	(2, 2, 1),
	(12, 8, 1),
	(13, 8, 6),
	(25, 13, 5),
	(26, 10, 6),
	(27, 10, 2),
	(28, 10, 1),
	(32, 9, 2),
	(33, 9, 8),
	(37, 12, 8),
	(38, 12, 1),
	(39, 1, 2),
	(40, 1, 8),
	(41, 1, 5),
	(42, 11, 1),
	(43, 11, 5),
	(44, 16, 9),
	(45, 16, 8),
	(46, 14, 5),
	(49, 17, 8),
	(50, 17, 1),
	(54, 18, 10),
	(55, 18, 1),
	(56, 18, 7),
	(59, 19, 1),
	(60, 22, 7),
	(61, 25, 11),
	(62, 26, 7),
	(63, 27, 7),
	(64, 28, 7),
	(67, 29, 7),
	(69, 30, 7),
	(70, 31, 7),
	(71, 32, 7),
	(72, 33, 7),
	(73, 34, 7),
	(74, 35, 7);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
