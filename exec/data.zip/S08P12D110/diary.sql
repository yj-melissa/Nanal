-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.diary 구조 내보내기
CREATE TABLE IF NOT EXISTS `diary` (
  `diary_idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(350) DEFAULT NULL,
  `creation_date` datetime(6) DEFAULT NULL,
  `delete_date` date DEFAULT NULL,
  `diary_date` date DEFAULT NULL,
  `emo` varchar(255) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL,
  `picture_idx` int(10) unsigned DEFAULT NULL,
  `user_idx` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`diary_idx`),
  KEY `FKcmhtdslypufc6fblv0e83revq` (`picture_idx`),
  KEY `FKb5hjikijgsyvndsf743gy58rw` (`user_idx`),
  CONSTRAINT `FKb5hjikijgsyvndsf743gy58rw` FOREIGN KEY (`user_idx`) REFERENCES `user` (`user_idx`),
  CONSTRAINT `FKcmhtdslypufc6fblv0e83revq` FOREIGN KEY (`picture_idx`) REFERENCES `painting` (`picture_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.diary:~35 rows (대략적) 내보내기
INSERT INTO `diary` (`diary_idx`, `content`, `creation_date`, `delete_date`, `diary_date`, `emo`, `expire_date`, `img_url`, `is_deleted`, `picture_idx`, `user_idx`) VALUES
	(1, '오늘은 브이로그를 촬영하는 날이다. ^ㅁ^\n혼자서 돌아다니는 모습을 담을 예정! \n핵밥에 가서 스테이크 덮밥을 먹었다.\n그리고 오늘 날씨가 좋아서 헤드셋을 챙겨서 공원에 갔다! 노래 들으면서 소설책도 읽고 \n오랜만에 여유로운 시간을 보냈다ㅎㅎ\n이번에 산 헤드셋을 아주 유용하게 사용하는 것 같아 뿌듯하다.ㅎㅎ', '2023-02-16 22:07:01.246075', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254520062189651.png', b'0', 71, 3),
	(2, '오늘 친구들이랑 볼링쳤다! 볼링은 언제나 재미있다! 다음에 또 볼링 치러가면 좋겠다!! 다음번엔 팀 나눠서 게임해야지!', '2023-02-16 22:10:32.525606', NULL, '2023-02-14', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1252841329173031.png', b'0', 17, 2),
	(3, '친구들과 치킨을 시켜 먹었다. 후라이드 치킨과 치즈볼을 주문했는데, 생각보다 배달이 늦게 됐지만 맛있었다.! 이불 빨래를 했는데 자취방은 빨래를 널 수 있는 공간이 너무 없어서 말리기가 힘들다. 오늘 날씨가 흐리고 습한 날이라서 제대로 마르지 않을까봐 걱정되지만 안하는 것보다는 낫겠지... 집안에 건조기가 있으면 좋겠다. 세탁소까지 가기 너무 귀찮은데..ㅠㅠ  날 잡고 가지 않으면 갈 수가 없다.  세탁 배달 서비스가 잘 돼있었으면 자주 썼을텐데 대충 살아야지 뭐... 그나저나 오늘은 뭘 덮고자야하지', '2023-02-16 22:14:18.379877', NULL, '2023-02-15', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_nerv_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253067120255994.png', b'0', 24, 2),
	(4, '카레라이스를 먹었다. 음료는 콜라를 먹었는데 정말 맛있었다.\n다음엔 하이라이스를 먹어야지.', '2023-02-16 22:18:40.000538', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253328787545220.png', b'0', 34, 7),
	(5, '귀여운 우리 강아지랑 함께 하는 저녁. 공원에 산책도 가고, 목욕도 시켰다. 밖에선 그렇게 신나 했으면서 목욕 시켰다고 삐지는 바람에 간식을 가져다 바쳤다. 다행히 간식을 먹고 나서는 기분이 풀렸는지 꼬리를 열심히 흔들고 있다.', '2023-02-16 22:19:22.535313', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253371324951714.png', b'0', 36, 5),
	(6, '2월 중순인데 눈이 내렸다! 아침에 잠이 덜 깨서 헛것을 보고 있나? 했는데 아니었다. 쌓일 정도는 아니었지만 그래도 눈이 와서 기분 좋음!', '2023-02-16 22:20:10.326666', NULL, '2023-02-15', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_ang_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253419057080334.png', b'0', 39, 5),
	(7, '건강클럽이라는 이름에 맞는 건강 보호 캠페인 : 눈이 피곤하다면 인공눈물을, 손목이 아프다면 버티컬 마우스와 손목 받침대를, 손가락이 아프다면 좋은 키보드를 삽시다. 근데 이런 거 적어도 되나?', '2023-02-16 22:22:13.123346', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253541943332742.png', b'0', 42, 5),
	(8, '오늘은 친구들이랑 스파게티를 먹었다! 스파게티라면 다 좋지만 요즘에는 알리오올리오 파스타가 더 맛있는거같다! 다음에 또 먹으러 가야지!', '2023-02-16 22:28:30.379953', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254072415441964.png', b'0', 61, 2),
	(9, '오늘 공통 팀원들과 다같이 저녁으로 고기듬뿍 핵밥을 먹고 볼링을 쳤다!! 볼링,, 아주 어렵다. 바람도 엄청 불었다. 다시 겨울이 오는 것 같았다.☃️☃️', '2023-02-16 22:29:42.412556', NULL, '2023-02-14', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253991214069839.png', b'0', 59, 3),
	(10, '오늘은 윗집 친구랑 저녁을 같이 먹었다!!\n고구마치즈돈까스와 냄비..우동 같은걸 먹었는데 또 가지는 않을 것 같다!! 하지만 맛있게 먹고 카페에 가서 열심히 공부했다ㅎㅎ', '2023-02-16 22:31:06.270692', NULL, '2023-02-15', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254503337851416.png', b'0', 70, 3),
	(11, '오늘은 신나는 월요일!!!😊\n오늘도 열심히 살았다. 이번주도 파이팅ㅎㅎ', '2023-02-16 22:33:58.969390', NULL, '2023-02-13', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254247732115438.png', b'0', 66, 3),
	(12, '분명히 일기예보에서 날씨가 따뜻하다고 해서 얇게입었는데 너무 추웠다 화가나... 얼어죽을뻔했다. ㅠㅠ', '2023-02-16 22:36:42.010745', NULL, '2023-02-15', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_ang_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254410834540831.png', b'0', 67, 3),
	(13, '아 진짜 월요일이 너무 금방 돌아오는거 같다! 화난다!', '2023-02-16 22:37:08.323923', '2023-02-16', '2023-02-13', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_ang_s.png', '2023-03-18', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254487143102514.png', b'1', 69, 2),
	(14, '오늘은 드라마를 봤다. 판타지 드라마였는데 재미있었다.\n특히 손가락으로 걸어 다니는 손바닥 괴물이 매력적이었다.', '2023-02-16 22:45:11.992404', NULL, '2023-02-09', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255034684702197.png', b'0', 77, 7),
	(15, '점심에 석쇠 불고기를 먹었는데 너무 맛있었다.\n봄이라서 날씨가 따뜻해진것 같다.\n갑자기 퇴근하고 싶다.ㅠ', '2023-02-16 22:47:35.025683', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255063790683556.png', b'0', 79, 10),
	(16, '난 내일 서울 간다.\n안녕~ ', '2023-02-16 22:47:54.022508', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255082778538633.png', b'0', 80, 10),
	(17, '아침에 출근하는데 ❄️눈❄️이와서 깜짝 놀랬다.!  눈보니까 ㅎㅎ.. 난 지방사람인가봐', '2023-02-16 22:49:25.208431', NULL, '2023-02-13', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255209470462394.png', b'0', 82, 3),
	(18, '나의 욕심,,,, 음악도 넣고 싶다.. 하지만 다들 반대했지 뮤직이즈마이라이프. 음악을 넣게 해줘ㅜㅜㅜ', '2023-02-16 22:53:18.224468', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255534268375400.png', b'0', 86, 1),
	(19, '내일은 발표일이다. 발표는 너무너무 떨린다. 다들 나는 떨리는 티가 안 난다고 하지만 나는 정말 떨린다... 발표는 떨리는 일.. 사실 내가 발표하지는 않지만ㅎㅎㅎ', '2023-02-16 23:03:56.319378', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_nerv_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1256045085760425.png', b'0', 87, 1),
	(20, '안녕!', '2023-02-16 23:09:44.109483', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1256392923882082.png', b'0', 88, 1),
	(21, '오늘은 팀 빌딩으로 인하여 살짝 뒤숭숭한 분위기가 되었다. 팀 생성 이후 자꾸 집중도 안 되고 너무 우울하다.', '2023-02-16 23:14:46.774268', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1256695541391745.png', b'0', 89, 1),
	(22, '프론트들은 오류를 고치느라 바쁘다', '2023-02-16 23:15:15.444859', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1256724052135604.png', b'0', 90, 1),
	(23, '오늘은 친구들과 볼링장에 가서 볼링을 쳤다. 다들 정말 볼링을 잘 쳤다. 나만 볼링을 못 했다ㅠㅜ 나도 볼링을 잘 치고 싶다. 100점을 넘기자 볼링...', '2023-02-16 23:31:15.832274', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1257684622340230.png', b'0', 93, 13),
	(24, '안녕!', '2023-02-16 23:44:24.134473', '2023-02-16', '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', '2023-03-18', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258472939594273.png', b'1', 103, 13),
	(25, '드디어 프로젝트가 마무리됐다. 우리 서비스는 일기쓰기 프로젝트다. 많은 사람들이 이용해주면 정말 좋겠다. 우리 팀원들 정말 고생많았어!', '2023-02-16 23:44:37.533518', NULL, '2023-02-16', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258486351396703.png', b'0', 104, 4),
	(26, '안녕하세요 오늘의 발표자입니다. 다들 발표 듣느라 고생이 많으세요. 곧 발표가 끝나니 조금만 기다려주세요. 다들 화이팅!', '2023-02-17 00:03:51.924540', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_ang_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1259640734728964.png', b'0', 105, 1),
	(27, '일기에 이모티콘이 드간다면? 🥳 어떻게 그림이 나올까?🤭', '2023-02-17 00:07:19.829964', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1259848654464736.png', b'0', 106, 1),
	(28, '일기에 이모티콘이 들어간다면? 🤗', '2023-02-17 00:14:25.701345', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260274519333928.png', b'0', 107, 1),
	(29, '안녕! 난 탕수육을 먹었어!🤗', '2023-02-17 00:17:04.915321', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260541163881934.png', b'0', 110, 1),
	(30, '오늘의 점심 일기! ✨닭갈비, 닭다리✨ 먹었다. 맛있어서 기분이 좋았다 🥰', '2023-02-17 00:19:52.910092', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260639870924274.png', b'0', 112, 1),
	(31, '날짜가 제대로 나오지 않아 슬픔에 잠긴다. 🥲 이모티콘은 또 왜 안 되는 걸까? 😢', '2023-02-17 00:22:41.624126', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260770327332154.png', b'0', 113, 1),
	(32, '오늘은 ucc를 위해 볼링장에 가서 볼링을 아주 재미있게 쳤다. 다들 너무 볼링을 잘 해서,, 부러웠다. 나도 볼링 잘 치고 싶다', '2023-02-17 00:39:06.549516', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1261755353320162.png', b'0', 114, 1),
	(33, '볼링 치기~', '2023-02-17 00:43:21.323084', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1262010106238948.png', b'0', 115, 1),
	(34, '오늘 오랜만에 친구랑 놀러 갔다 왔다. 친구랑 공원에서 피크닉을 즐기며 힐링하려고 계획을 세웠다. 공원에 가니 날씨도 너무 좋고 사람도 적고 완벽한 날이었다. 자리를 잡고 돗자리를 펼친 후 바로 음식부터 준비했다. 음식을 엄청 많이 놓고 열심히 먹기 시작했다. 맛있는걸 먹어서 행복했다! 오늘 하루 너무 완벽한 하루였다. 다음에도 또 친구랑 피크닉 가서 힐링하면 좋겠다!', '2023-02-17 00:48:02.753140', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1262291554057574.png', b'0', 116, 1),
	(35, '오늘 오랜만에 친구랑 놀러 갔다 왔다. 친구랑 공원에서 피크닉을 즐기며 힐링하려고 계획을 세웠다. 공원에 가니 날씨도 너무 좋고 사람도 적고 완벽한 날이었다. 자리를 잡고 돗자리를 펼친 후 바로 음식부터 준비했다. 음식을 엄청 많이 놓고 열심히 먹기 시작했다. 맛있는걸 먹어서 행복했다! 오늘 하루 너무 완벽한 하루였다. 다음에도 또 친구랑 피크닉 가서 힐링하면 좋겠다!', '2023-02-17 00:53:46.247469', NULL, '2023-02-17', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1262635059003469.png', b'0', 117, 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
