-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.group_detail 구조 내보내기
CREATE TABLE IF NOT EXISTS `group_detail` (
  `group_idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) DEFAULT NULL,
  `group_img_idx` int(11) NOT NULL,
  `group_name` varchar(30) DEFAULT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `is_private` bit(1) DEFAULT NULL,
  PRIMARY KEY (`group_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.group_detail:~11 rows (대략적) 내보내기
INSERT INTO `group_detail` (`group_idx`, `creation_date`, `group_img_idx`, `group_name`, `img_url`, `is_private`) VALUES
	(1, '2023-02-16 22:05:11.044000', 0, 'Back’s', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253653193470700null', b'0'),
	(2, '2023-02-16 22:16:06.458000', 0, '바람개비파🧚‍♀️', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253840899792892null', b'0'),
	(3, '2023-02-16 22:18:36.164000', 35, '건강클럽', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', b'0'),
	(4, '2023-02-16 22:18:41.519000', 0, '건강클럽', NULL, b'0'),
	(5, '2023-02-16 22:19:30.666000', 65, '13일의월요일', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254197977057511null', b'0'),
	(6, '2023-02-16 22:19:46.238000', 0, '자취생들', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253584066926448null', b'0'),
	(7, '2023-02-16 22:30:31.099000', 0, 'Front\'s', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254087474266482null', b'0'),
	(8, '2023-02-16 22:40:50.807000', 0, '공통 프로젝트', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254679394124253null', b'0'),
	(9, '2023-02-16 22:47:00.203000', 78, '컨설턴트님', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255038025837261null', b'0'),
	(10, '2023-02-16 22:51:35.046000', 83, '나의 욕심', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255304004365972null', b'0'),
	(11, '2023-02-16 23:39:03.805000', 0, '안녕', 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258231017122839null', b'0');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
