-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.friend 구조 내보내기
CREATE TABLE IF NOT EXISTS `friend` (
  `friend_idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_idx` int(10) unsigned DEFAULT NULL,
  `user_idx2` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`friend_idx`),
  KEY `FKbs16119lx3t1qbn6id0c5rbga` (`user_idx`),
  KEY `FK42y8d97xwbt9b8ryew5yfoxpn` (`user_idx2`),
  CONSTRAINT `FK42y8d97xwbt9b8ryew5yfoxpn` FOREIGN KEY (`user_idx2`) REFERENCES `user` (`user_idx`),
  CONSTRAINT `FKbs16119lx3t1qbn6id0c5rbga` FOREIGN KEY (`user_idx`) REFERENCES `user` (`user_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.friend:~34 rows (대략적) 내보내기
INSERT INTO `friend` (`friend_idx`, `user_idx`, `user_idx2`) VALUES
	(1, 3, 2),
	(2, 2, 3),
	(3, 5, 3),
	(4, 3, 5),
	(5, 2, 5),
	(6, 5, 2),
	(7, 2, 7),
	(8, 7, 2),
	(9, 7, 3),
	(10, 3, 7),
	(11, 7, 5),
	(12, 5, 7),
	(13, 1, 2),
	(14, 2, 1),
	(15, 1, 5),
	(16, 5, 1),
	(17, 1, 3),
	(18, 3, 1),
	(19, 4, 7),
	(20, 7, 4),
	(21, 4, 5),
	(22, 5, 4),
	(23, 10, 1),
	(24, 1, 10),
	(25, 10, 3),
	(26, 3, 10),
	(27, 10, 7),
	(28, 7, 10),
	(29, 10, 2),
	(30, 2, 10),
	(31, 13, 4),
	(32, 4, 13),
	(33, 1, 7),
	(34, 7, 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
