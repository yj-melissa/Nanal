-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.group_tag 구조 내보내기
CREATE TABLE IF NOT EXISTS `group_tag` (
  `tag_idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(255) DEFAULT NULL,
  `group_idx` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`tag_idx`),
  KEY `FK6huej2mn2on24hu9ao3nmwt1h` (`group_idx`),
  CONSTRAINT `FK6huej2mn2on24hu9ao3nmwt1h` FOREIGN KEY (`group_idx`) REFERENCES `group_detail` (`group_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.group_tag:~55 rows (대략적) 내보내기
INSERT INTO `group_tag` (`tag_idx`, `tag`, `group_idx`) VALUES
	(1, '백엔드', 1),
	(2, '스프링부트', 1),
	(3, 'DB', 1),
	(4, 'Server', 1),
	(5, 'Jenkins', 1),
	(6, '바개파', 2),
	(7, '울산', 2),
	(8, '', 2),
	(9, '', 2),
	(10, '', 2),
	(11, '명상', 3),
	(12, '건강', 3),
	(13, '헬스', 3),
	(14, '요가', 3),
	(15, 'PT', 3),
	(16, '명상', 4),
	(17, '건강', 4),
	(18, '헬스', 4),
	(19, '요가', 4),
	(20, 'PT', 4),
	(21, '2023', 5),
	(22, '02', 5),
	(23, '13', 5),
	(24, '월', 5),
	(25, '요일좋아', 5),
	(26, '구미', 6),
	(27, '인동', 6),
	(28, '진평동', 6),
	(29, '', 6),
	(30, '', 6),
	(31, 'front', 7),
	(32, '전용', 7),
	(33, '그룹', 7),
	(34, '', 7),
	(35, '', 7),
	(36, '시연 영상을', 8),
	(37, '위한', 8),
	(38, '그룹입니다', 8),
	(39, '', 8),
	(40, '', 8),
	(41, '개인', 9),
	(42, '컨설턴트님', 9),
	(43, '혼자 보는 그룹', 9),
	(44, '', 9),
	(45, '', 9),
	(46, '음악도', 10),
	(47, '넣고 싶다', 10),
	(48, '', 10),
	(49, '', 10),
	(50, '', 10),
	(51, '하이', 11),
	(52, '나는', 11),
	(53, '테스트용이야', 11),
	(54, '안녕!', 11),
	(55, '', 11);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
