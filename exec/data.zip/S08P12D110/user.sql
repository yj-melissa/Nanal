-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.user 구조 내보내기
CREATE TABLE IF NOT EXISTS `user` (
  `user_idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `last_access_date` datetime(6) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `social_code` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `emotion_idx` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_idx`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`),
  UNIQUE KEY `UK_a3imlf41l37utmxiquukk8ajc` (`user_id`),
  KEY `FKthm0q79j21xih8dw3ckdhyxns` (`emotion_idx`),
  CONSTRAINT `FKthm0q79j21xih8dw3ckdhyxns` FOREIGN KEY (`emotion_idx`) REFERENCES `emotion` (`emotion_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.user:~15 rows (대략적) 내보내기
INSERT INTO `user` (`user_idx`, `creation_date`, `email`, `last_access_date`, `name`, `password`, `social_code`, `user_id`, `emotion_idx`) VALUES
	(1, '2023-02-16 22:01:55.316044', 'eyk79602@zslsz.com', '2023-02-17 01:39:51.811659', NULL, '$2a$10$af7cnB.oVIckoriSg0G3LOlGzQ5l.5q1OsI.W1b4Ovq66ochlwvvm', 0, 'test1', NULL),
	(2, '2023-02-16 22:02:36.202633', 'jgd18383@zslsz.com', '2023-02-17 01:38:54.728241', NULL, '$2a$10$t/qsr3LZSNjjLFMaXXOGKuOkFqBue.Yxr3O80MsWsBddzIwuRCYYe', 0, 'test2', NULL),
	(3, '2023-02-16 22:03:04.665983', 'akb88989@zslsz.com', '2023-02-16 22:03:53.944229', NULL, '$2a$10$0fCoNe7GOs0Ba7GwIFlWvebNSoNjyNmlUwbgSeBrKbPvMUMD..jV2', 0, 'test3', NULL),
	(4, '2023-02-16 22:03:35.143718', 'lnx10330@omeie.com', '2023-02-17 00:28:34.926151', NULL, '$2a$10$r/2m9nXHc5OLpmMXQXlIBeohJsPs.cwI4iRhhrFgP.uGgUJhBNb1.', 0, 'test4', NULL),
	(5, '2023-02-16 22:04:10.171971', 'myf64698@omeie.com', '2023-02-17 01:38:23.095095', NULL, '$2a$10$cjT3QFQvgHEs.ln8x3m39.K03zFRSmxYwS2.EPU68jg8ClqPbwHp.', 0, 'test5', NULL),
	(6, '2023-02-16 22:04:52.557955', 'gzf00970@omeie.com', '2023-02-16 22:04:52.556703', NULL, '$2a$10$7eJXIgojrO8SCdF0OoQBp.AsalfzY5uPBT21NOEhW4EwtB96MDc52', 1, 'test7', NULL),
	(7, '2023-02-16 22:05:11.142070', 'oea05353@nezid.com', '2023-02-17 01:40:20.826374', NULL, '$2a$10$gr0fa0dkG4hSFdNCVvwx8.ORVRY1lRXjE5S2Lp1DHBlcvg8Rqtcqq', 0, 'test6', NULL),
	(8, '2023-02-16 22:12:25.176429', 'zex13320@nezid.com', '2023-02-16 22:12:25.166683', NULL, '$2a$10$BG.MjDAC57qFnaqbw6ldbuI1DQXYf7l4VzhHitcLwuPa8HSvwTyvq', 0, 'test8', NULL),
	(9, '2023-02-16 22:12:58.020187', 'wix87344@nezid.com', '2023-02-16 22:12:58.010879', NULL, '$2a$10$aRUDc7UEw7OMJwgCoXYz.OoT2AJeZ1J4IPVxsCcEIzmxsf/M3zs/O', 0, 'test9', NULL),
	(10, '2023-02-16 22:13:18.260929', 'amp89818@zslsz.com', '2023-02-16 22:34:14.174684', NULL, '$2a$10$VuNizOjAeebHL5GwysXYpu4riXfhpAAPruAS73ru/GuCDDrjIhs.W', 0, 'test10', NULL),
	(11, '2023-02-16 22:14:57.815227', 'tuf54894@zslsz.com', '2023-02-16 22:14:57.805503', NULL, '$2a$10$loIfH.NrQ/Plz/1a1SE2neZPm4ODTHe.1iT/Mby1r5BEz3cfMLunS', 0, 'test11', NULL),
	(12, '2023-02-16 22:15:19.188703', 'qtn33917@zslsz.com', '2023-02-16 22:15:19.179218', NULL, '$2a$10$Oy3bm94k53MLsh0wavzWW.nkHbxmxcb3Y2itZZd4bqIkWbXIpxgV2', 0, 'test12', NULL),
	(13, '2023-02-16 23:29:15.551102', 'ybc51499@nezid.com', '2023-02-17 00:29:42.986939', NULL, '$2a$10$8knSlseURC.wSshuq1imMuvFP5xdPCmCUB3EK6v90MhYheChh9unq', 0, 'test15', NULL),
	(15, '2023-02-17 01:19:21.639688', 'test13@naver.com', '2023-02-17 01:19:21.638712', NULL, '$2a$10$8knSlseURC.wSshuq1imMuvFP5xdPCmCUB3EK6v90MhYheChh9unq', 1, 'test13', NULL),
	(16, '2023-02-17 01:27:50.628763', 'test14@gmail.com', '2023-02-17 01:27:50.627908', NULL, '$2a$10$8knSlseURC.wSshuq1imMuvFP5xdPCmCUB3EK6v90MhYheChh9unq', 1, 'test14', NULL),
	(17, '2023-02-17 01:55:29.244214', 'test16@gmail.com', '2023-02-17 01:55:29.243295', NULL, '$2a$10$8knSlseURC.wSshuq1imMuvFP5xdPCmCUB3EK6v90MhYheChh9unq', 1, 'test16', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
