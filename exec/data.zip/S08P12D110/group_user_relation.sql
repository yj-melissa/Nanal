-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.group_user_relation 구조 내보내기
CREATE TABLE IF NOT EXISTS `group_user_relation` (
  `group_user_idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `is_notice` bit(1) DEFAULT NULL,
  `group_idx` int(10) unsigned DEFAULT NULL,
  `user_idx` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`group_user_idx`),
  KEY `FKlie0ualnu3w03tfis88baaxrh` (`group_idx`),
  KEY `FKmfi8wu8ngso5t2ka5x19ldkt5` (`user_idx`),
  CONSTRAINT `FKlie0ualnu3w03tfis88baaxrh` FOREIGN KEY (`group_idx`) REFERENCES `group_detail` (`group_idx`),
  CONSTRAINT `FKmfi8wu8ngso5t2ka5x19ldkt5` FOREIGN KEY (`user_idx`) REFERENCES `user` (`user_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.group_user_relation:~24 rows (대략적) 내보내기
INSERT INTO `group_user_relation` (`group_user_idx`, `is_notice`, `group_idx`, `user_idx`) VALUES
	(1, b'0', 1, 2),
	(2, b'0', 1, 3),
	(3, b'0', 2, 3),
	(4, b'0', 2, 2),
	(7, b'0', 5, 7),
	(8, b'0', 6, 3),
	(9, b'0', 6, 2),
	(10, b'0', 5, 2),
	(11, b'0', 5, 3),
	(12, b'0', 1, 1),
	(13, b'0', 7, 1),
	(14, b'0', 8, 10),
	(15, b'0', 8, 3),
	(16, b'0', 8, 2),
	(17, b'0', 9, 10),
	(18, b'0', 8, 7),
	(19, b'0', 2, 7),
	(20, b'0', 10, 1),
	(21, b'0', 11, 13),
	(22, b'0', 11, 4),
	(23, b'0', 8, 1),
	(24, b'0', 2, 1),
	(25, b'0', 6, 1),
	(26, b'0', 7, 2);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
