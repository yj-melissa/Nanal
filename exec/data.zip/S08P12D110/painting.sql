-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.painting 구조 내보내기
CREATE TABLE IF NOT EXISTS `painting` (
  `picture_idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creation_date` datetime(6) DEFAULT NULL,
  `file_size` bigint(20) NOT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `picture_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`picture_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.painting:~118 rows (대략적) 내보내기
INSERT INTO `painting` (`picture_idx`, `creation_date`, `file_size`, `img_url`, `picture_title`) VALUES
	(1, '2023-02-16 22:01:55.277000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL),
	(2, '2023-02-16 22:01:55.343000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL),
	(3, '2023-02-16 22:02:36.193000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(4, '2023-02-16 22:02:36.209000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(5, '2023-02-16 22:03:04.657000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL),
	(6, '2023-02-16 22:03:04.671000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL),
	(7, '2023-02-16 22:03:35.134000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(8, '2023-02-16 22:03:35.151000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(9, '2023-02-16 22:04:10.163000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL),
	(10, '2023-02-16 22:04:10.178000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL),
	(11, '2023-02-16 22:05:11.130000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(12, '2023-02-16 22:05:11.152000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(13, '2023-02-16 22:05:11.160000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL),
	(14, '2023-02-16 22:05:20.403000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(15, '2023-02-16 22:05:42.938000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(16, '2023-02-16 22:07:01.237000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1252629672579750.png', 'Dalle'),
	(17, '2023-02-16 22:10:32.519000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1252841329173031.png', 'Dalle'),
	(18, '2023-02-16 22:12:25.168000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL),
	(19, '2023-02-16 22:12:25.187000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL),
	(20, '2023-02-16 22:12:58.012000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL),
	(21, '2023-02-16 22:12:58.026000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL),
	(22, '2023-02-16 22:13:18.253000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_ang_s.png', NULL),
	(23, '2023-02-16 22:13:18.266000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_ang_s.png', NULL),
	(24, '2023-02-16 22:14:18.374000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253067120255994.png', 'Dalle'),
	(25, '2023-02-16 22:14:57.807000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(26, '2023-02-16 22:14:57.822000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(27, '2023-02-16 22:15:19.180000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL),
	(28, '2023-02-16 22:15:19.193000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL),
	(29, '2023-02-16 22:16:06.526000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL),
	(30, '2023-02-16 22:16:57.677000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253226485902525.png', '마이멜로디.png'),
	(31, '2023-02-16 22:18:04.456000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL),
	(32, '2023-02-16 22:18:10.287000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253299074283710null', 'image.jpg'),
	(33, '2023-02-16 22:18:36.200000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL),
	(34, '2023-02-16 22:18:39.994000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253328787545220.png', 'Dalle'),
	(35, '2023-02-16 22:18:41.558000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL),
	(36, '2023-02-16 22:19:22.529000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253371324951714.png', 'Dalle'),
	(37, '2023-02-16 22:19:30.787000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253379624112785null', 'image.jpg'),
	(38, '2023-02-16 22:19:46.294000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL),
	(39, '2023-02-16 22:20:10.317000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253419057080334.png', 'Dalle'),
	(40, '2023-02-16 22:21:44.042000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253512808933096null', 'image.jpg'),
	(41, '2023-02-16 22:21:51.820000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_nerv_s.png', NULL),
	(42, '2023-02-16 22:22:13.118000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253541943332742.png', 'Dalle'),
	(43, '2023-02-16 22:22:53.478000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(44, '2023-02-16 22:22:55.363000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253584066926448null', 'image.jpg'),
	(45, '2023-02-16 22:23:49.857000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253638660051006null', 'image.jpg'),
	(46, '2023-02-16 22:24:04.382000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253653193470700null', 'image.jpg'),
	(47, '2023-02-16 22:24:39.000000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253687819640204null', 'image.jpg'),
	(48, '2023-02-16 22:24:44.218000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253693049649115null', 'image.jpg'),
	(49, '2023-02-16 22:25:13.317000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253722143475642null', 'image.jpg'),
	(50, '2023-02-16 22:25:18.781000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253727549178634null', 'image.jpg'),
	(51, '2023-02-16 22:26:15.123000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253783932929327null', 'image.jpg'),
	(52, '2023-02-16 22:27:12.148000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253840899792892null', 'image.jpg'),
	(53, '2023-02-16 22:27:56.267000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253885045182595null', 'image.jpg'),
	(54, '2023-02-16 22:28:02.533000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253891280331916null', 'image.jpg'),
	(55, '2023-02-16 22:28:21.701000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253910519674756null', 'image.jpg'),
	(56, '2023-02-16 22:28:30.374000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253919127187476.png', 'Dalle'),
	(57, '2023-02-16 22:29:15.301000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253964088444310null', 'image.jpg'),
	(58, '2023-02-16 22:29:33.923000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253982658825676.png', 'Dalle'),
	(59, '2023-02-16 22:29:42.407000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253991214069839.png', 'Dalle'),
	(60, '2023-02-16 22:30:31.154000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL),
	(61, '2023-02-16 22:31:03.661000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254072415441964.png', 'Dalle'),
	(62, '2023-02-16 22:31:06.265000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254075076392121.png', 'Dalle'),
	(63, '2023-02-16 22:31:07.898000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254076728741665null', 'image.jpg'),
	(64, '2023-02-16 22:31:18.654000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254087474266482null', 'image.jpg'),
	(65, '2023-02-16 22:33:09.166000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254197977057511null', 'image.jpg'),
	(66, '2023-02-16 22:33:58.964000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254247732115438.png', 'Dalle'),
	(67, '2023-02-16 22:36:42.002000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254410834540831.png', 'Dalle'),
	(68, '2023-02-16 22:37:08.319000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254437141458887.png', 'Dalle'),
	(69, '2023-02-16 22:37:58.325000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254487143102514.png', 'Dalle'),
	(70, '2023-02-16 22:38:14.518000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254503337851416.png', 'Dalle'),
	(71, '2023-02-16 22:38:31.298000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254520062189651.png', 'Dalle'),
	(72, '2023-02-16 22:40:50.860000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', NULL),
	(73, '2023-02-16 22:41:10.574000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254679394124253null', 'image.jpg'),
	(74, '2023-02-16 22:45:11.988000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254920783306500.png', 'Dalle'),
	(75, '2023-02-16 22:46:27.000000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1254995825089600.png', 'Dalle'),
	(76, '2023-02-16 22:47:00.251000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL),
	(77, '2023-02-16 22:47:05.912000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255034684702197.png', 'Dalle'),
	(78, '2023-02-16 22:47:09.161000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255038025837261null', 'image.jpg'),
	(79, '2023-02-16 22:47:35.020000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255063790683556.png', 'Dalle'),
	(80, '2023-02-16 22:47:54.017000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255082778538633.png', 'Dalle'),
	(81, '2023-02-16 22:49:25.203000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255174012445927.png', 'Dalle'),
	(82, '2023-02-16 22:50:00.637000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255209470462394.png', 'Dalle'),
	(83, '2023-02-16 22:51:35.173000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255304004365972null', 'image.jpg'),
	(84, '2023-02-16 22:53:18.219000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255407022163649.png', 'Dalle'),
	(85, '2023-02-16 22:54:05.573000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255454413300731null', 'image.jpg'),
	(86, '2023-02-16 22:55:25.480000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255534268375400.png', 'Dalle'),
	(87, '2023-02-16 23:03:56.314000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1256045085760425.png', 'Dalle'),
	(88, '2023-02-16 23:09:44.104000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1256392923882082.png', 'Dalle'),
	(89, '2023-02-16 23:14:46.769000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1256695541391745.png', 'Dalle'),
	(90, '2023-02-16 23:15:15.439000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1256724052135604.png', 'Dalle'),
	(91, '2023-02-16 23:29:15.544000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL),
	(92, '2023-02-16 23:29:15.555000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL),
	(93, '2023-02-16 23:31:15.827000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1257684622340230.png', 'Dalle'),
	(94, '2023-02-16 23:32:45.553000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1257774336710143null', 'image.jpg'),
	(95, '2023-02-16 23:32:53.254000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_nerv_s.png', NULL),
	(96, '2023-02-16 23:36:40.071000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258008913500922null', 'image.jpg'),
	(97, '2023-02-16 23:36:43.715000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_nerv_s.png', NULL),
	(98, '2023-02-16 23:37:13.418000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258042227051745null', 'image.jpg'),
	(99, '2023-02-16 23:37:48.197000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_nerv_s.png', NULL),
	(100, '2023-02-16 23:38:10.553000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258099388211033null', 'image.jpg'),
	(101, '2023-02-16 23:39:03.943000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258152769230070null', 'image.jpg'),
	(102, '2023-02-16 23:40:22.276000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258231017122839null', 'image.jpg'),
	(103, '2023-02-16 23:44:24.129000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258472939594273.png', 'Dalle'),
	(104, '2023-02-16 23:44:37.528000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258486351396703.png', 'Dalle'),
	(105, '2023-02-17 00:03:51.917000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1259640734728964.png', 'Dalle'),
	(106, '2023-02-17 00:07:19.824000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1259848654464736.png', 'Dalle'),
	(107, '2023-02-17 00:14:25.696000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260274519333928.png', 'Dalle'),
	(108, '2023-02-17 00:17:04.910000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260433728201676.png', 'Dalle'),
	(109, '2023-02-17 00:18:32.880000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260521704871819.png', 'Dalle'),
	(110, '2023-02-17 00:18:52.340000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260541163881934.png', 'Dalle'),
	(111, '2023-02-17 00:19:52.904000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260601663626829.png', 'Dalle'),
	(112, '2023-02-17 00:20:31.051000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260639870924274.png', 'Dalle'),
	(113, '2023-02-17 00:22:41.617000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1260770327332154.png', 'Dalle'),
	(114, '2023-02-17 00:39:06.544000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1261755353320162.png', 'Dalle'),
	(115, '2023-02-17 00:43:21.315000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1262010106238948.png', 'Dalle'),
	(116, '2023-02-17 00:48:02.745000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1262291554057574.png', 'Dalle'),
	(117, '2023-02-17 00:53:46.242000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1262635059003469.png', 'Dalle'),
	(118, '2023-02-17 01:12:09.015000', 0, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
