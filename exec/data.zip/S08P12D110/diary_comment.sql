-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.diary_comment 구조 내보내기
CREATE TABLE IF NOT EXISTS `diary_comment` (
  `comment_idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `creation_date` datetime(6) DEFAULT NULL,
  `parent_comment_idx` int(11) DEFAULT NULL,
  `diary_idx` int(10) unsigned DEFAULT NULL,
  `group_idx` int(10) unsigned DEFAULT NULL,
  `user_idx` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`comment_idx`),
  KEY `FKmtjiidjp4073pupmih9oq8eqc` (`diary_idx`),
  KEY `FKjn67xwbh9vkpbjea5v4lfrn5e` (`group_idx`),
  KEY `FKd47ibagwftledpsmw9r1exgtl` (`user_idx`),
  CONSTRAINT `FKd47ibagwftledpsmw9r1exgtl` FOREIGN KEY (`user_idx`) REFERENCES `user` (`user_idx`),
  CONSTRAINT `FKjn67xwbh9vkpbjea5v4lfrn5e` FOREIGN KEY (`group_idx`) REFERENCES `group_detail` (`group_idx`),
  CONSTRAINT `FKmtjiidjp4073pupmih9oq8eqc` FOREIGN KEY (`diary_idx`) REFERENCES `diary` (`diary_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.diary_comment:~11 rows (대략적) 내보내기
INSERT INTO `diary_comment` (`comment_idx`, `content`, `creation_date`, `parent_comment_idx`, `diary_idx`, `group_idx`, `user_idx`) VALUES
	(1, '오! 스테이크 덮밥 맛있었어??? 나도 브이로그 볼래!', '2023-02-16 22:39:37.568787', 0, 1, 2, 2),
	(2, '소희 볼링퀸👸💙', '2023-02-16 22:41:19.705409', 0, 2, 1, 3),
	(3, '아이 럽 먼데이 뭘닝 i love monday morning', '2023-02-16 22:49:20.744686', 0, 11, 5, 7),
	(4, '나랑도 가주ㅓ,,,,', '2023-02-16 22:50:57.220533', 0, 8, 6, 3),
	(5, '이때는 드라마 볼 여유가 있었나보다🥲', '2023-02-16 22:53:01.823986', 0, 14, 5, 3),
	(6, '그래!!! 파스타 먹으러 가자!', '2023-02-16 22:53:02.061870', 0, 8, 6, 2),
	(7, '다음 기회에...', '2023-02-16 22:58:11.128614', 0, 18, 1, 2),
	(8, '다들 수고했어!!!', '2023-02-16 23:44:53.488155', 0, 25, 11, 13),
	(10, '다음에 볼링 또 치러가자~~~', '2023-02-17 00:40:53.884316', 0, 32, 7, 2),
	(11, '볼링 재밌어!!', '2023-02-17 00:44:04.915415', 0, 33, 7, 2),
	(12, '피크닉 다음에 같이가자~~!! 🐣', '2023-02-17 00:48:25.266219', 0, 34, 7, 2);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
