-- --------------------------------------------------------
-- 호스트:                          3.36.51.212
-- 서버 버전:                        10.10.2-MariaDB-1:10.10.2+maria~ubu2204 - mariadb.org binary distribution
-- 서버 OS:                        debian-linux-gnu
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 테이블 S08P12D110.user_profile 구조 내보내기
CREATE TABLE IF NOT EXISTS `user_profile` (
  `user_idx` int(10) unsigned NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `introduction` varchar(255) DEFAULT NULL,
  `is_private` bit(1) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `picture_idx` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_idx`),
  UNIQUE KEY `UK_m9ga0crhcge7onj1gx9a5lnjy` (`nickname`),
  KEY `FKii4olg27iblc9m123897g78lh` (`picture_idx`),
  CONSTRAINT `FKewmquuycnxhxk15lg7brrr6qr` FOREIGN KEY (`user_idx`) REFERENCES `user` (`user_idx`),
  CONSTRAINT `FKii4olg27iblc9m123897g78lh` FOREIGN KEY (`picture_idx`) REFERENCES `painting` (`picture_idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 S08P12D110.user_profile:~15 rows (대략적) 내보내기
INSERT INTO `user_profile` (`user_idx`, `img`, `introduction`, `is_private`, `nickname`, `picture_idx`) VALUES
	(1, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1255454413300731null', '나는 박소연!\n😊😊😊😊😊😊😊😊', NULL, '소연', 85),
	(2, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', '🍅나는야 토마토🍅', NULL, 'test2', 4),
	(3, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_joy_s.png', 'Jw', NULL, 'test3', 6),
	(4, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', '안녕하세요! 저는 나날입니다.', NULL, 'test4', 8),
	(5, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', '안녕하세요! 10조 나날입니다.', NULL, 'test5', 10),
	(6, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL, b'0', 'test7', NULL),
	(7, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1253226485902525.png', '이 캐릭터 어디서 많이 봤는데 뭐였지\n마이멜로디다!', NULL, 'test6', 30),
	(8, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL, NULL, 'test8', 19),
	(9, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_calm_s.png', NULL, NULL, 'test9', 21),
	(10, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_ang_s.png', NULL, NULL, 'test10', 23),
	(11, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_emb_s.png', NULL, NULL, 'test11', 26),
	(12, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/emotion/emo_sad_s.png', NULL, NULL, 'test12', 28),
	(13, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258099388211033null', '안녕 난 프로젝트를 위해 태어난 계정이야!', NULL, '프로젝트', 100),
	(15, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258099388211033null', NULL, b'0', 'test13', NULL),
	(16, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258099388211033null', NULL, b'0', 'test14', NULL),
	(17, 'https://nanal-dbd.s3.ap-northeast-2.amazonaws.com/dalle/1258099388211033null', NULL, b'0', 'test16', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
